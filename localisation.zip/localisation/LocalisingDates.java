package localisation;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Locale;

public class LocalisingDates {
    public static void main(String[] args) {
        Locale locUS     = Locale.US;               
        Locale locFrench = new Locale("fr", "FR");  
        Locale locIndia = new Locale("en", "IN");
        
        LocalDateTime ldt = LocalDateTime.now();
        System.out.println(ldt);

//        DateTimeFormatter dateMediumStyle    = DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM);
//        System.out.println(dateMediumStyle.withLocale(locUS).format(ldt));     
//        System.out.println(dateMediumStyle.withLocale(locFrench).format(ldt));
//        System.out.println(dateMediumStyle.withLocale(locIndia).format(ldt));
        

//        DateTimeFormatter timeShortStyle     = DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT);
//        System.out.println(timeShortStyle.withLocale(locUS).format(ldt));      
//        System.out.println(timeShortStyle.withLocale(locIndia).format(ldt));  
//
//        DateTimeFormatter datetimeShortStyle = DateTimeFormatter.ofLocalizedDateTime(FormatStyle.SHORT);
//        System.out.println(datetimeShortStyle.format(ldt));                   
//        System.out.println(datetimeShortStyle.withLocale(locUS).format(ldt)); 

    }
}
