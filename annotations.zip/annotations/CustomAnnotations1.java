package annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE_USE)
@interface Company {
	String companyName() default "CLSA";

	String city() default "Pune";
	String[] presence() default { "India", "US" };
}

@Company()
class Employee {

}

public class CustomAnnotations1 {
	public static void main(String[] args) {
		Class<Employee> myClass = Employee.class;
		Company company = myClass.getAnnotation(Company.class);
		if (company != null) {
			System.out.println(company.companyName());
			System.out.println(company.city());
			System.out.println(company.presence()[0]);
		}
	}
}
