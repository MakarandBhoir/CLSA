package annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Field;

@Target(ElementType.TYPE_USE)
@Retention(RetentionPolicy.RUNTIME)
@interface Entity{
	String tableName() default "";
}
@Target({ElementType.FIELD, ElementType.METHOD})
@interface Id{
	
}
@Target({ElementType.FIELD, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@interface Column{
	String name() default "";
}

@Entity(tableName="students")
class Student2{
	@Id
	@Column(name="student_name")
	private String name;
	
	@Column(name="student_score")
	private String score;

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getScore() {
		return score;
	}
	public void setScore(String score) {
		this.score = score;
	}
}

public class CustomAnnotations2{
	public static void main(String[] args) throws NoSuchFieldException, SecurityException {
		Class<Student2> studentClass = Student2.class;
		Entity entity =  studentClass.getAnnotation(Entity.class);		

		Column column = studentClass.getDeclaredField("name").getAnnotation(Column.class);
		
		System.out.println(entity.tableName());
		System.out.println(column.name());
	}
}
