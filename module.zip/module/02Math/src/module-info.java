module math.util {
	exports com.makarands.math;
}