package java8_02_mr;

import java.util.Arrays;

public class Test3 {

	public static void main(String[] args) {
		String[] stringArray = { "Jagadesh", "Asifa", "Sukrutha", "Navya", "Anish", "Deepak", "Vamsi" };
		/*
		 * Method reference to an instance method of an arbitrary object of a particular
		 * type
		 */
		Arrays.sort(stringArray, String::compareToIgnoreCase);
		for (String str : stringArray) {
			System.out.println(str);
		}
	}
}