package java8_02_mr;

@FunctionalInterface
interface MyInterface2 {
	Hello display(String say);
}

class Hello {
	public Hello(String say) {
		System.out.print(say);
	}
}

public class Test4 {
	public static void main(String[] args) {
		// Method reference to a constructor
		MyInterface2 ref = Hello::new;
		ref.display("Hello World!");
	}
}