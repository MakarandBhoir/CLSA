package java8_02_mr;

@FunctionalInterface
interface MyInterface {
	void display();
}

public class Test1 {
	public void myMethod() {
		System.out.println("Instance Method");
	}

	public static void main(String[] args) {
		Test1 obj = new Test1();
		// Method reference using the object of the class
		MyInterface ref = obj::myMethod;
		// Calling the method of functional interface
		ref.display();
	}
}