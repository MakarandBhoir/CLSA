package stream;

import java.util.Arrays;
import java.util.List;

public class Assignment_04 {
    public static void main(String[] args) {
        List<Book> books = Arrays.asList(new Book("Thinking in Java", 3000.0),  
                                         new Book("Java in 24 hrs", 2000.0),   
                                         new Book("Java Recipies", 1000.0)); 
        double averagePrice = books.stream()
                .filter(book->book.getPrice()>10)    
                .mapToDouble(book->book.getPrice())     
                // OptionalDouble average()  - terminal operation
                .average()
//                .getAsDouble(); 
                .orElse(0.0); // useful if filter filters out ALL of the Books
        System.out.println(averagePrice);       
    }
    
}
