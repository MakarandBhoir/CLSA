package stream;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.stream.Collectors;

public class Assignment_05 {
    public static void main(String[] args) {
        List<Book> books = Arrays.asList(        
                new Book("Two States", 250.0),         
                new Book("Dongari To Dubai", 250.0),         
                new Book("Why I killed Gandhi", 200.0) );
        // API: 
        //   An object that maps keys to values. 
        //   A map cannot contain duplicate keys; each key can map to at most one value.
        Map<String, Double> bookMap = books.stream()
                                		.collect(Collectors.toMap((b->b.getTitle()), b->b.getPrice())); 
        //System.out.println("Map == "+bookMap);
        BiConsumer<String, Double> funcBC = (a, b)->{ //define the lambda (not executing yet)
            if(a.startsWith("D")){
                System.out.println(b);
            } 
        };
        bookMap.forEach(funcBC);// execute lambda;   Map::forEach(BiConsumer) 
        
        // option D
        // using a Set here as opposed to a Map
        Set<Entry<String, Double>> bookSet = bookMap.entrySet();
        Consumer<Map.Entry<String, Double>> funcC = (e)->{ 
            if(e.getKey().startsWith("D")){ 
                System.out.println(e.getValue()); 
            } 
        };
        bookSet.forEach(funcC); // Set::forEach(Consumer)
    }
}
