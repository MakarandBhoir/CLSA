package stream;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class Assignment_02 {
    public static void main(String[] args) {
          List<Item> l = Arrays.asList(                 
                  new Item(1, "Screw"),                 
                  new Item(2, "Nail"),                 
                  new Item(3, "Bolt")         
          );
//          	l.stream()          // Option 1
//          		.sorted((a, b)->a.getId().compareTo(b.getId()))     
//          		.forEach(System.out::print); // Sorted by id. Output: ScrewNailBolt  

//	        l.stream()          // Option 2
//	        	.sorted(Comparator.comparing(a->a.getName())) // sorting by name
//	        	.forEach(System.out::print); // Sorted by name, as we wanted. Output: BoltNailScrew  

//            l.stream()          // Option 3
//            	.map((i)->i.getName())    // mapping to a Stream<String> 
//            	.forEach(System.out::print); // Not sorted at all. Output: ScrewNailBolt  

            l.stream()          // Option 4
            	.map((i)->i.getName())  // mapping to a Stream<String>
            	.sorted()               // sort by the String's natural order
            	.forEach(System.out::print); // Sorted by name, as we wanted. Output: BoltNailScrew  
    }  
}


