package security;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
//connect 'jdbc:derby:d:\files\mydb;create=true'
public class SQLInjection {

	private static Connection con;
    
    public void openConnection() {
        try {
        	System.out.println("START");
            con = DriverManager 
                    .getConnection("jdbc:derby:d:\\files\\mydb"); // don't expose your password!
            System.out.println("DB connection OK!");
        } catch (SQLException ex) { // SQLEXception is a checked exception
            System.err.println("Exception.");
            ex.printStackTrace();
        }
    }
    
	public void retrieveUsingStatement(String branchCode) {
		openConnection();
		String sql = "SELECT * FROM APP.BANK_TABLE WHERE BRANCH_CODE = "+branchCode+"";
		BankAccount bankAccount = null;
		
		try(Statement stmt = con.createStatement()){
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()) {
				bankAccount = new BankAccount(rs.getString("BRANCH_CODE"), rs.getString("Account_Number"), rs.getString("CUST_NAME"), rs.getString("CUST_ADDRESS"), rs.getDouble("BALANCE"));
				System.out.println(bankAccount);
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void retrieveUsingPrepareStatement(String branchCode) {
		openConnection();
		String sql = "SELECT * FROM APP.BANK_TABLE WHERE BRANCH_CODE = ?";
		BankAccount bankAccount = null;
		
		try(PreparedStatement pstmt = con.prepareStatement(sql)){
			pstmt.setString(1, branchCode);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()) {
				bankAccount = new BankAccount(rs.getString("BRANCH_CODE"), rs.getString("Account_Number"), rs.getString("CUST_NAME"), rs.getString("CUST_ADDRESS"), rs.getDouble("BALANCE"));
				System.out.println(bankAccount);
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
//		new SQLInjection().retrieveUsingStatement("'123456'");
//		new SQLInjection().retrieveUsingStatement("'123456' OR BRANCH_CODE IS NOT NULL");
//		new SQLInjection().retrieveUsingPrepareStatement("123456");
//		new SQLInjection().retrieveUsingPrepareStatement("123456 OR BRANCH_CODE IS NOT NULL");
	}

}
