package security;

import java.util.ArrayList;

public class TestImmutable {
	public static void main(String[] args) {
		ArrayList<String> employees = new ArrayList<>();
		employees.add("makarand");
		employees.add("rohit");
		
		Department dept = Department.createNewDept("Training", "Mumbai", 2, employees);
		System.out.println("Created: "+dept);
		
		String name = dept.getName();
		String address = dept.getAddress();
		int numEmployees = dept.getNumEmployees();
		employees = dept.getEmployees();
		
		System.out.println(name+" "+address+" "+numEmployees+" "+employees);
//		dept.setName("IT"); // if we not declare final then can break immutability
		name = "IT";
		address = "Pune";
		numEmployees = 3;
		employees.add("John");
		
		System.out.println("Any changes?: "+dept);
	}
}
