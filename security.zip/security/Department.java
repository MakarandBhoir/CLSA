package security;

import java.util.ArrayList;

public final class Department {
	private String name, address;
	private final int numEmployees;
	private final ArrayList<String> employees;
		
	private Department(String name, String address, int numEmployees, ArrayList<String> employees) {
		super();
		this.name = name;
		this.address = address;
		this.numEmployees = numEmployees;
		this.employees = employees;
//		this.employees = new ArrayList<>(employees);
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public int getNumEmployees() {
		return numEmployees;
	}
	public ArrayList<String> getEmployees() {
		return employees;
//		return new ArrayList<>(employees);
	}
	
	public static Department createNewDept(String name, String address, int numEmployees, ArrayList<String> employees) {
		return new Department(name, address, numEmployees, employees);
	}
	@Override
	public String toString() {
		return "Department [name=" + name + ", address=" + address + ", numEmployees=" + numEmployees + ", employees="
				+ employees + "]";
	}
	
}
